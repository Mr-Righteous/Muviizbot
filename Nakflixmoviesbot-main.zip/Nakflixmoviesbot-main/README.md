![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=Wᴇʟᴄᴏᴍᴇ+Tᴏ+Aᴡᴇsᴏᴍᴇ+Fɪʟᴛᴇʀ+Pʀᴏ+Rᴇᴘᴏ+!!!!!;Cʀᴇᴀᴛᴇᴅ+Bʏ+ɴᴀᴋғʟɪx+Tᴇᴀᴍ+!!!!!;Mᴀᴅᴇ+Wɪᴛʜ+Lᴏᴠᴇ+♥️+!!!!)</p>
<p align="center">
  <img src="https://graph.org/file/f3c1d9f76aa1f08bceaf5.jpg" alt="NAKFLIX LOGO">
  </p>
  <h1 align="center">
    <b>AᴡᴇsᴏᴍᴇFɪʟᴛᴇʀ Pʀᴏ</b>
    </h1>

👩‍💻 Vᴇʀsɪᴏɴ :- 0.1 ✨

🌟 Fᴏʀᴋ & Sᴛᴀʀ Nᴏᴡ 💥

## HɪɢʜLɪɢʜᴛ Fᴇᴀᴛᴜʀᴇs

- 🔥Uʀʟ Sʜᴏʀᴛɴᴇʀ Sᴜᴘᴘᴏʀᴛ (ᴀʟʟ sɪᴛᴇs)
- 🔥Hᴏᴡ Tᴏ Dᴏᴡɴʟᴏᴀᴅ Bᴜᴛᴛᴏɴ
- 🔥Aᴜᴛᴏ Dᴇʟᴇᴛᴇ Iɴ Gʀᴏᴜᴘ
- 🔥Lᴏᴀᴅɪɴɢ Eғғᴇᴄᴛ
- 🔥Pᴍ Sᴇᴀʀᴄʜ Sᴜᴘᴘᴏʀᴛ
- 🔥Nᴇᴡ & Bᴇsᴛ Uɪ
- 🔥SʜᴀʀᴇMᴇ Bᴜᴛᴛᴏɴ 
- 🔥Eᴍᴏᴊɪ's Iɴ Fɪʟᴛᴇʀ
- 🔥Fɪʟᴇs Uɴᴅᴇʀ Dᴇʟᴇᴛᴇ Bᴜᴛᴛᴏɴ
- 🔥Aᴜᴛᴏ Fɪʟᴛᴇʀ Oɴ/Oғғ
- 🔥Fᴜʟʟʏ Sᴍᴀʟʟ Cᴀᴘs Fᴏɴᴛ
- 🔥Lᴏɢ Mᴇssᴀɢᴇ Cʜᴀɴɢᴇᴅ
- 🔥100% Bᴇᴛᴛᴇʀ Tʜᴀɴ Eᴠᴀ Mᴀʀɪᴇ Rᴇᴘᴏ


### Mᴜsᴛ AᴅᴅVᴀʀɪᴀʙʟᴇs

- `BOT_TOKEN` 👈 ᴄʀᴇᴀᴛᴇ ᴀ ʙᴏᴛ ғʀᴏᴍ ʙᴏᴛғᴀᴛʜᴇʀ
- `API_ID` 👈 ɢᴇᴛ ᴀᴘɪ ɪᴅ ғʀᴏᴍ ( Telegram.Org )
- `API_HASH` 👈 ɢᴇᴛ ᴀᴘɪ ʜᴀsʜ ғʀᴏᴍ ( Telegram.Org )
- `CHANNELS` 👈 ᴄʀᴇᴀᴛᴇ ᴀ ᴅʙ ᴄʜᴀɴɴᴇʟ ᴀɴᴅ ᴀᴅᴍɪɴ ᴛʜᴇ ᴅᴇᴘᴏʟʏ ʙᴏᴛ
- `ADMINS` 👈 ɢᴇᴛ ᴜʀ ɪᴅ ғʀᴏᴍ ( @MissRose_bot ) ʙᴏᴛ
- `DATABASE_URI` 👈 ɢᴇᴛ ᴍᴏɴɢᴏᴅʙ ᴜʀʟ ғʀᴏᴍ ( mongodb.com )
- `DATABASE_NAME` 👈 ɢᴇᴛ ᴍᴏɴɢᴏᴅʙ ɴᴀᴍᴇ ғʀᴏᴍ ( mongodb.com )
- `LOG_CHANNEL` 👈 ᴄʀᴇᴀᴛᴇ ᴀ ʟᴏɢ ᴄʜᴀɴɴᴇʟ ᴀɴᴅ ᴀᴅᴍɪɴ ᴛʜᴇ ᴅᴇᴘᴏʟʏ ʙᴏᴛ
- `SHORTENER_SITE` 👈 ɢɪᴠᴇ ᴜʀ sʜᴏʀᴛɴᴇʀ ᴡᴇʙsɪᴛᴇ ʟɪɴᴋ 
- `SHORTENER_API` 👈 ɢᴇᴛ ᴀᴘɪ ғʀᴏᴍ ᴜʀ sʜᴏʀᴛɴᴇʀ ᴡᴇʙsɪᴛᴇ sᴇᴛᴛɪɴɢs
- `AUTO_DELETE_SECONDS` 👈 ɢɪᴠᴇ ɪɴ sᴇᴄᴏɴᴅs ғᴏʀᴍᴀᴛ

## Mᴜsᴛ Dᴏ Bᴇғᴏʀᴇ Eᴅɪᴛ Tʜɪs Rᴇᴘᴏ 👇

 - 💗 Sᴛᴀʀ Tʜɪs Rᴇᴘᴏ 🌟 - Sᴜᴘᴘᴏʀᴛ ɴᴀᴋғʟɪx ᵗᵛ—͟͟͞͞𖣘 Cᴏᴍᴍᴜɴɪᴛʏ 💥 -

ɴᴀᴋғʟɪx ᵗᵛ—͟͟͞͞𖣘

ɴᴀᴋғʟɪx ᵖˡᵘˢ—͟͟͞͞𖣘



## Dᴇᴘᴏʟʏ
Yᴏᴜ Cᴀɴ Dᴇᴘᴏʟʏ Tʜɪs Rᴇᴘᴏ AɴʏWʜᴇʀᴇ

<details><summary>Dᴇᴘᴏʟʏ Tᴏ Hᴇʀᴏᴋᴜ {ᴘᴀɪᴅ}</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/nakflix/Nakflixmoviesbot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
  </a>
  </p>
  </details>

<details><summary>Dᴇᴘᴏʟʏ Tᴏ Rᴇɴᴅᴇʀ {ғʀᴇᴇ}</summary>
<p>
<br>
<a href="https://dashboard.render.com/select-repo?type=web">
  <img src="https://render.com/images/deploy-to-render-button.svg" alt="deploy-to-render">
  </a>
  </p>
  <p>
</details>
<details><summary>Dᴇᴘᴏʟʏ Tᴏ Kᴏʏᴇʙ {ғʀᴇᴇ}</summary>
<p>
<br>
<a href="https://app.koyeb.com/deploy?type=git&repository=github.com/nakflix/Nakflixmoviesbot&branch=main">
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="deploy-to-koyeb">
  </a>
  </p>
  <p>
</details>  
<details><summary>Dᴇᴘᴏʟʏ Tᴏ Oᴋᴛᴇᴛᴏ {ᴘᴀɪᴅ}</summary>
<p>
<br>
<a href="https://cloud.okteto.com/deploy?repository=https://github.com/nakflix/Nakflixmoviesbot">
  <img src="https://okteto.com/develop-okteto.svg" alt="deploy-to-okteto">
  </a>
  </p>
  </details>
<details><summary>Dᴇᴘᴏʟʏ Tᴏ Rᴀɪʟᴡᴀʏ {ғʀᴇᴇ}</summary>
<p>
<br>
<a href="https://railway.app/new/template?template=https%3A%2F%2Fgithub.com%2Fnakflix%2Fnakflixmoviesbot">
  <img src="https://railway.app/button.svg" alt="deploy-to-railway">
  </a>
  </p>
  </details>
<details><summary>Rᴜɴ Lᴏᴄᴀʟʟʏ/Vᴘs {ᴘᴀɪᴅ}</summary>
<p>
You must have the latest version of <a href="golang.org">go</a> installed first
<pre>
git clone https://github.com/nakflix/Nakflixmoviesbot
cd AwesomeFilterPro
go build .
./AwesomeFilterPro
</pre>
</p>
</details>

## Cᴏᴍᴍᴀɴᴅs
```
start -✨ ᴄʜᴇᴄᴋ ᴀʟɪᴠᴇ/ɢᴇᴛ ғɪʟᴇs 
stats - 👩‍💻ʙᴏᴛ sᴛᴀᴛs
connect - 😇ᴄᴏɴɴᴇᴄᴛ ᴛᴏ ᴜʀ ɢʀᴏᴜᴘ
info - ℹ️ɢᴇᴛ ᴜʀ ɪɴғᴏ
imdb - 📇ɢᴇᴛ ɪᴍᴅʙ ɪɴғᴏ
users - 💗ʟɪsᴛ ᴏғ ᴛᴏᴛᴀʟ ᴜsᴇʀs
index - 📁ɪɴᴅᴇx ғɪʟᴇs
chats - 🕳️ᴛᴏᴛᴀʟ ᴄʜᴀᴛs ɪɴғᴏ
broadcast - 🔮ʙʀᴏᴀᴅᴄᴀsᴛ (ᴀᴅᴍɪɴ ᴏɴʟʏ )
ban - 🤕ʙᴀɴ ᴀɴʏ ᴜsᴇʀ (ᴀᴅᴍɪɴ ᴏɴʟʏ)
unban - 🙇ᴜɴʙᴀɴ ᴀɴʏ ᴜsᴇʀ (ᴀᴅᴍɪɴ ᴏɴʟʏ)
link - 🖇️ʟɪɴᴋ ᴛᴏ ᴘᴏsᴛ (ᴀᴅᴍɪɴ ᴏɴʟʏ)
```

## Cʀᴇᴅɪᴛs


## Tʜᴀɴᴋs Tᴏ 
 - Tʜᴀɴᴋs Tᴏ Mᴇ 🤩
 - Tʜᴀɴᴋs Tᴏ Eᴠᴀ Mᴀʀɪᴇ Tᴇᴀᴍ❣️
 - Tʜᴀɴᴋs Tᴏ Oᴜʀ Usᴇʀs😇

## Dɪsᴄʟᴀᴍɪɴᴇʀ

- Tʜɪs Is OᴘᴇɴSᴏᴜʀᴄᴇ Pʀᴏᴊᴇᴄᴛ Sᴏ Dᴏɴ'ᴛ Sᴇʟʟ Tʜɪs Rᴇᴘᴏ Fᴏʀ Mᴏɴᴇʏ
- Pʟᴇᴀsᴇ Dᴏɴ'ᴛ Cʜᴀɴɢᴇ "Uᴘᴅᴀᴛᴇs" Bᴜᴛᴛᴏɴ Lɪɴᴋ
- Mʏ 1ᴍᴏɴᴛʜ HᴀʀᴅWᴏʀᴋ Sᴏ Pʟᴇᴀsᴇ 'Sᴛᴀʀ' (10 Sᴇᴄ Fᴏʀ Sᴛᴀʀ)
